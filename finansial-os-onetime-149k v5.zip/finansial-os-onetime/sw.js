// sw.js — Service Worker untuk Finansial OS
// Versi cache — update angka ini setiap kali ada perubahan file
const CACHE = 'finansial-os-v1';

const ASSETS = [
  '/',
  '/index.html',
  '/dashboard.html',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
];

// Install: cache semua asset penting
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(ASSETS))
  );
  self.skipWaiting();
});

// Activate: hapus cache lama
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE).map(k => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

// Fetch: cache-first untuk asset lokal, network-first untuk Supabase
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);

  // Selalu ambil dari network untuk Supabase & CDN (butuh data terbaru)
  if (
    url.hostname.includes('supabase.co') ||
    url.hostname.includes('jsdelivr.net') ||
    url.hostname.includes('googleapis.com')
  ) {
    e.respondWith(fetch(e.request));
    return;
  }

  // Cache-first untuk asset lokal
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request))
  );
});
