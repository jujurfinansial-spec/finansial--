# PANDUAN INTEGRASI MIDTRANS — FINANSIAL OS
## Sandbox Mode (Testing)

---

## KONFIGURASI YANG SUDAH DIISI

| Item | Value |
|---|---|
| Mode | **Sandbox (Testing)** |
| Client Key (frontend) | `Mid-client-OWH5NR-DbwX1018q` |
| Server Key (backend) | `Mid-server-bZU_TlxY0Yru3KULrQIcjqM5` |

> ⚠️ **PENTING:** Server Key TIDAK boleh ada di file HTML/frontend.
> Hanya boleh ada di Supabase Edge Function via environment variable.
> Client Key aman di frontend (sudah dimasukkan ke `dashboard.html`).

---

## LANGKAH 1 — DEPLOY EDGE FUNCTIONS KE SUPABASE

### Install Supabase CLI dulu (sekali saja)

```bash
npm install -g supabase
```

### Login ke Supabase

```bash
supabase login
```

### Link project ke Supabase kamu

```bash
supabase link --project-ref mmkzyojuvnecncssxouu
```

### Set environment variables (Server Key & konfigurasi lain)

```bash
supabase secrets set MIDTRANS_SERVER_KEY=Mid-server-bZU_TlxY0Yru3KULrQIcjqM5
supabase secrets set MIDTRANS_IS_PRODUCTION=false
supabase secrets set APP_URL=https://URL-NETLIFY-KAMU.netlify.app
```

Untuk Service Role Key (dibutuhkan webhook):
1. Buka Supabase Dashboard → Settings → API
2. Copy **service_role** key (BUKAN anon key)
3. Jalankan:
```bash
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=<paste-service-role-key>
```

### Deploy kedua Edge Functions

```bash
supabase functions deploy create-payment
supabase functions deploy midtrans-webhook
```

Setelah deploy, kamu dapat URL seperti:
- `https://mmkzyojuvnecncssxouu.supabase.co/functions/v1/create-payment`
- `https://mmkzyojuvnecncssxouu.supabase.co/functions/v1/midtrans-webhook`

---

## LANGKAH 2 — SET WEBHOOK URL DI MIDTRANS

1. Login ke `dashboard.sandbox.midtrans.com`
2. **Settings** → **Configuration**
3. Isi **Payment Notification URL**:
   ```
   https://mmkzyojuvnecncssxouu.supabase.co/functions/v1/midtrans-webhook
   ```
4. Klik **Save**

Ini yang membuat akun pembeli aktif **otomatis** setelah pembayaran sukses.

---

## LANGKAH 3 — TEST DI SANDBOX

Midtrans menyediakan kartu kredit test dan akun e-wallet test:

### Test dengan Kartu Kredit Sandbox:
| Field | Value |
|---|---|
| Card Number | `4811 1111 1111 1114` |
| Expiry | Bulan/tahun apapun di masa depan |
| CVV | `123` |
| OTP | `112233` |

### Test dengan GoPay Sandbox:
1. Di popup Midtrans pilih GoPay
2. Klik "Pay with GoPay"
3. Gunakan nomor HP test: `08123456789`
4. PIN: `123456`

### Test dengan QRIS Sandbox:
1. Pilih QRIS
2. Screenshot QR code
3. Scan dengan aplikasi apapun (tidak akan benar-benar charge)
4. Status otomatis jadi "Paid" setelah beberapa detik

---

## LANGKAH 4 — SWITCH KE PRODUCTION

Setelah testing OK dan akun Midtrans sudah diverifikasi:

### 1. Update `dashboard.html`:
```javascript
// Baris 440 — ganti false ke true
const MIDTRANS_IS_PRODUCTION = true;

// Baris 439 — ganti ke Production Client Key
const MIDTRANS_CLIENT_KEY = 'Mid-client-XXXXX'; // dari dashboard production Midtrans
```

### 2. Update Supabase secrets:
```bash
supabase secrets set MIDTRANS_SERVER_KEY=Mid-server-XXXXX  # Production Server Key
supabase secrets set MIDTRANS_IS_PRODUCTION=true
```

### 3. Update webhook URL di Midtrans Production:
- Login ke `dashboard.midtrans.com` (bukan sandbox)
- Settings → Configuration → Payment Notification URL → isi URL yang sama

### 4. Redeploy Edge Functions:
```bash
supabase functions deploy create-payment
supabase functions deploy midtrans-webhook
```

---

## ALUR PEMBAYARAN LENGKAP

```
User klik "Beli Sekarang" di dashboard
        ↓
dashboard.html → POST /functions/v1/create-payment
        ↓
Edge Function → Midtrans API → dapat token
        ↓
Midtrans Snap popup muncul di browser
(pilih: transfer bank / QRIS / GoPay / dll)
        ↓
User bayar
        ↓
Midtrans → POST webhook ke /functions/v1/midtrans-webhook
        ↓
Edge Function verifikasi signature → update tabel subscriptions
        ↓
User refresh / dashboard otomatis aktif ✅
```

---

## TROUBLESHOOTING

**"Gagal membuat transaksi"**
→ Cek apakah Edge Function sudah di-deploy
→ Cek apakah MIDTRANS_SERVER_KEY sudah di-set di secrets

**Popup Midtrans tidak muncul**
→ Pastikan Client Key sudah benar di dashboard.html
→ Cek console browser untuk error

**Akun tidak aktif setelah bayar**
→ Cek apakah webhook URL sudah diset di Midtrans dashboard
→ Lihat log Edge Function: Supabase → Edge Functions → midtrans-webhook → Logs

**Test pembayaran selalu pending**
→ Normal untuk beberapa metode di sandbox
→ Gunakan kartu kredit test untuk hasil instan
