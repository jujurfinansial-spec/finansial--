// supabase/functions/create-payment/index.ts
// Edge Function — buat Midtrans Snap token untuk transaksi one-time
//
// Deploy: supabase functions deploy create-payment
// Set secret: supabase secrets set MIDTRANS_SERVER_KEY=Mid-server-bZU_TlxY0Yru3KULrQIcjqM5

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // 1. Verifikasi user via Supabase Auth
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) throw new Error('Unauthorized')

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    )

    const { data: { user }, error: userError } = await supabase.auth.getUser()
    if (userError || !user) throw new Error('Unauthorized')

    // 2. Ambil data dari request
    const { order_id, amount, email, name, description } = await req.json()

    if (!order_id || !amount) throw new Error('Missing order_id or amount')

    // 3. Cek apakah sudah pernah bayar
    const { data: sub } = await supabase
      .from('subscriptions')
      .select('status, plan')
      .eq('user_id', user.id)
      .single()

    if (sub?.status === 'active' && sub?.plan === 'lifetime') {
      throw new Error('Akun sudah aktif')
    }

    // 4. Buat Midtrans Snap Token
    const MIDTRANS_SERVER_KEY = Deno.env.get('MIDTRANS_SERVER_KEY') ?? ''
    const IS_PRODUCTION = false // Sandbox mode

    const midtransUrl = IS_PRODUCTION
      ? 'https://app.midtrans.com/snap/v1/transactions'
      : 'https://app.sandbox.midtrans.com/snap/v1/transactions'

    const payload = {
      transaction_details: {
        order_id,
        gross_amount: amount,
      },
      customer_details: {
        email: email || user.email,
        first_name: name || user.user_metadata?.full_name || 'User',
      },
      item_details: [
        {
          id:       'FINANSIAL-OS-PRO',
          price:     amount,
          quantity:  1,
          name:      description || 'Finansial OS Pro — Akses Selamanya',
          brand:     'Jujur Finansial',
          category:  'Digital Product',
        }
      ],
      // Metode pembayaran yang ditampilkan
      enabled_payments: [
        'credit_card',
        'gopay',
        'shopeepay',
        'other_qris',
        'bca_va',
        'bni_va',
        'bri_va',
        'permata_va',
        'mandiri_bill',
        'indomaret',
        'alfamart',
      ],
      callbacks: {
        finish: Deno.env.get('APP_URL') + '/dashboard.html',
      },
      // Simpan metadata untuk webhook
      custom_field1: user.id,
      custom_field2: 'finansial-os-pro',
      custom_field3: 'one-time',
    }

    const midtransRes = await fetch(midtransUrl, {
      method: 'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': 'Basic ' + btoa(MIDTRANS_SERVER_KEY + ':'),
      },
      body: JSON.stringify(payload),
    })

    if (!midtransRes.ok) {
      const err = await midtransRes.text()
      console.error('Midtrans error:', err)
      throw new Error('Gagal membuat transaksi Midtrans')
    }

    const { token, redirect_url } = await midtransRes.json()

    // 5. Simpan order_id ke database untuk verifikasi webhook
    await supabase
      .from('subscriptions')
      .upsert({
        user_id:     user.id,
        plan:        'pending',
        status:      'pending',
        payment_ref: order_id,
      })

    return new Response(
      JSON.stringify({ token, redirect_url, order_id }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
