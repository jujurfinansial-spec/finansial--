// supabase/functions/midtrans-webhook/index.ts
// Webhook dari Midtrans — otomatis aktifkan akun setelah pembayaran sukses
//
// Deploy: supabase functions deploy midtrans-webhook
// Set di Midtrans Dashboard → Settings → Configuration → Payment Notification URL:
// https://<project-id>.supabase.co/functions/v1/midtrans-webhook

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { crypto } from 'https://deno.land/std@0.168.0/crypto/mod.ts'

serve(async (req) => {
  try {
    const body = await req.json()
    console.log('Midtrans webhook:', JSON.stringify(body))

    const {
      order_id,
      status_code,
      gross_amount,
      signature_key,
      transaction_status,
      fraud_status,
      custom_field1: user_id,
    } = body

    // 1. Verifikasi signature dari Midtrans (keamanan)
    const MIDTRANS_SERVER_KEY = Deno.env.get('MIDTRANS_SERVER_KEY') ?? ''
    const rawStr = order_id + status_code + gross_amount + MIDTRANS_SERVER_KEY
    const encoder = new TextEncoder()
    const hashBuffer = await crypto.subtle.digest('SHA-512', encoder.encode(rawStr))
    const hashArray  = Array.from(new Uint8Array(hashBuffer))
    const expectedSig = hashArray.map(b => b.toString(16).padStart(2, '0')).join('')

    if (expectedSig !== signature_key) {
      console.error('Signature mismatch!')
      return new Response('Unauthorized', { status: 401 })
    }

    // 2. Cek status pembayaran
    const isSuccess = (
      transaction_status === 'capture'  && fraud_status === 'accept' ||
      transaction_status === 'settlement'
    )
    const isPending  = transaction_status === 'pending'
    const isFailed   = ['deny', 'cancel', 'expire', 'failure'].includes(transaction_status)

    if (!user_id) {
      console.error('No user_id in custom_field1')
      return new Response('Missing user_id', { status: 400 })
    }

    // 3. Update database Supabase
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '' // pakai service role untuk bypass RLS
    )

    if (isSuccess) {
      // Aktifkan akses selamanya
      const { error } = await supabase
        .from('subscriptions')
        .upsert({
          user_id,
          plan:        'lifetime',
          status:      'active',
          started_at:  new Date().toISOString(),
          expires_at:  '2099-12-31T23:59:59+00:00',
          payment_ref: order_id,
        })

      if (error) {
        console.error('DB error:', error)
        return new Response('DB error', { status: 500 })
      }

      console.log('✅ Akun diaktifkan untuk user:', user_id)

    } else if (isPending) {
      await supabase
        .from('subscriptions')
        .upsert({ user_id, plan: 'pending', status: 'pending', payment_ref: order_id })

      console.log('⏳ Pending payment untuk user:', user_id)

    } else if (isFailed) {
      await supabase
        .from('subscriptions')
        .upsert({ user_id, plan: 'pending', status: 'failed', payment_ref: order_id })

      console.log('❌ Payment failed untuk user:', user_id)
    }

    return new Response('OK', { status: 200 })

  } catch (err) {
    console.error('Webhook error:', err)
    return new Response('Error', { status: 500 })
  }
})
