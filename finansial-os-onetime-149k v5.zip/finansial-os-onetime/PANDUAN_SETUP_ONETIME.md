# PANDUAN SETUP FINANSIAL OS — VERSI ONE-TIME (Rp 149.000)
## Perbedaan dari versi langganan tahunan

---

## PERBEDAAN UTAMA vs VERSI LANGGANAN

| | Versi Langganan | Versi One-Time (ini) |
|---|---|---|
| Harga | Rp 79.000/tahun | **Rp 149.000 sekali bayar** |
| Masa aktif | 1 tahun per pembayaran | **Selamanya** |
| Trial | 7 hari gratis | Tidak ada |
| Model | Recurring revenue | One-time revenue |
| Cocok untuk | Cash flow rutin | Konversi lebih mudah |

---

## SETUP DATABASE (berbeda dari versi langganan)

Di Supabase SQL Editor, jalankan query ini (GANTI dari versi langganan):

```sql
-- Tabel data keuangan user
CREATE TABLE user_data (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id     UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  data        JSONB DEFAULT '{}',
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Tabel akses one-time
CREATE TABLE subscriptions (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id     UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  plan        TEXT DEFAULT 'pending',
  status      TEXT DEFAULT 'inactive',
  started_at  TIMESTAMPTZ,
  expires_at  TIMESTAMPTZ DEFAULT '2099-12-31 23:59:59+00',
  payment_ref TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- RLS
ALTER TABLE user_data      ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions  ENABLE ROW LEVEL SECURITY;

CREATE POLICY "User akses data sendiri" ON user_data
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "User akses subscription sendiri" ON subscriptions
  FOR ALL USING (auth.uid() = user_id);

-- Auto-buat row saat user baru daftar (status: inactive)
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO subscriptions (user_id, plan, status)
  VALUES (NEW.id, 'pending', 'inactive');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();
```

---

## AKTIVASI MANUAL SETELAH PEMBAYARAN

Setiap ada pembayaran masuk, jalankan query ini di Supabase SQL Editor:

```sql
UPDATE subscriptions
SET
  plan        = 'lifetime',
  status      = 'active',
  started_at  = NOW(),
  expires_at  = '2099-12-31 23:59:59+00',
  payment_ref = 'NOMOR-ORDER-GUMROAD-ATAU-TRANSFER'
WHERE user_id = (
  SELECT id FROM auth.users WHERE email = 'email@pembeli.com'
);
```

Ganti:
- `email@pembeli.com` → email pembeli
- `NOMOR-ORDER-GUMROAD-ATAU-TRANSFER` → referensi pembayaran

---

## SETUP GUMROAD UNTUK ONE-TIME

1. Buka `gumroad.com` → **New Product** → pilih **Digital Product** (bukan Subscription)
2. Isi:
   - **Name:** Finansial OS Pro — Akses Selamanya
   - **Price:** Rp 149.000 (atau setara USD ~$9)
   - **Description:** Dashboard keuangan terintegrasi 4-in-1. Bayar sekali, akses selamanya.
3. Di **Content** → tambahkan pesan:
   > "Terima kasih! Akun kamu akan diaktifkan dalam 1x24 jam setelah pembayaran dikonfirmasi. Kirim email bukti pembayaran ke [email kamu]."
4. Publish → copy link
5. Paste link ke `dashboard.html` di baris:
   ```javascript
   const PAYMENT_URL = 'GANTI_DENGAN_LINK_PEMBAYARAN';
   ```

---

## SETUP LANGKAH LAINNYA

Semua langkah lain (Supabase credentials, Google OAuth, Netlify deploy, PWA)
sama persis dengan panduan utama di `PANDUAN_SETUP.md`.

---

## PROYEKSI REVENUE ONE-TIME

| Subscriber | Revenue Kotor | Revenue Bersih (setelah komisi Gumroad 10%) |
|---|---|---|
| 10 orang | Rp 1.490.000 | Rp 1.341.000 |
| 50 orang | Rp 7.450.000 | Rp 6.705.000 |
| 100 orang | Rp 14.900.000 | Rp 13.410.000 |
| 500 orang | Rp 74.500.000 | Rp 67.050.000 |

---

## TIPS KONVERSI UNTUK YOUTUBE

- Tampilkan di deskripsi: **"Finansial OS Pro — Rp 149.000 akses selamanya (bukan langganan)"**
- Angle yang kuat: *"Sekali bayar, pakai seumur hidup"*
- Bisa tawarkan harga early bird ke 50 pembeli pertama: Rp 99.000
- Setelah 50 pembeli → naik ke Rp 149.000
