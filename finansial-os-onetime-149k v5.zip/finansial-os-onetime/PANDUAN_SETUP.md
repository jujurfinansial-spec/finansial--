# PANDUAN SETUP FINANSIAL OS
## Dari file HTML ke aplikasi berbayar yang berjalan

---

## GAMBARAN BESAR

```
index.html        → Landing page + form login
dashboard.html    → Dashboard utama (hanya bisa diakses setelah login + berlangganan)
manifest.json     → PWA config (agar bisa diinstall di HP)
```

Stack yang dipakai:
- **Supabase** — database + autentikasi Google + penyimpanan data user
- **Netlify** — hosting gratis, deploy otomatis
- **Midtrans / Gumroad** — terima pembayaran Rupiah

Estimasi waktu setup: **2–3 jam pertama kali**, berikutnya 5 menit per update.

---

## LANGKAH 1 — SETUP SUPABASE (30 menit)

### 1.1 Buat akun & project

1. Buka `supabase.com` → klik **Start your project**
2. Daftar dengan GitHub atau email
3. Klik **New Project**
4. Isi:
   - **Name:** `finansial-os`
   - **Database Password:** buat password kuat, simpan di tempat aman
   - **Region:** pilih `Southeast Asia (Singapore)`
5. Klik **Create new project** → tunggu 2–3 menit

### 1.2 Ambil kredensial

1. Di sidebar kiri → klik **Settings** → **API**
2. Catat dua nilai ini:
   - **Project URL** → contoh: `https://abcxyz.supabase.co`
   - **anon public key** → string panjang dimulai `eyJ...`
3. Buka file `index.html` dan `dashboard.html`
4. Ganti kedua baris ini di KEDUA file:
   ```javascript
   const SUPABASE_URL      = 'GANTI_DENGAN_SUPABASE_URL';
   const SUPABASE_ANON_KEY = 'GANTI_DENGAN_SUPABASE_ANON_KEY';
   ```

### 1.3 Buat tabel database

Di Supabase dashboard → klik **SQL Editor** → klik **New Query** → paste kode ini → klik **Run**:

```sql
-- Tabel data keuangan user
CREATE TABLE user_data (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id     UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  data        JSONB DEFAULT '{}',
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Tabel langganan
CREATE TABLE subscriptions (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id     UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  plan        TEXT DEFAULT 'trial',
  status      TEXT DEFAULT 'active',
  started_at  TIMESTAMPTZ DEFAULT NOW(),
  expires_at  TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '7 days'),
  payment_ref TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Row Level Security (RLS) — user hanya bisa akses data sendiri
ALTER TABLE user_data      ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions   ENABLE ROW LEVEL SECURITY;

CREATE POLICY "User akses data sendiri" ON user_data
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "User akses subscription sendiri" ON subscriptions
  FOR ALL USING (auth.uid() = user_id);

-- Function untuk auto-buat trial saat user baru daftar
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO subscriptions (user_id, plan, status, expires_at)
  VALUES (NEW.id, 'trial', 'active', NOW() + INTERVAL '7 days');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();
```

Klik **Run** → harus muncul "Success. No rows returned."

### 1.4 Aktifkan Google Login

1. Di Supabase → **Authentication** → **Providers**
2. Klik **Google** → toggle **Enable**
3. Kamu perlu **Google Client ID** dan **Client Secret**:

   **Cara dapat Google Client ID:**
   a. Buka `console.cloud.google.com`
   b. Buat project baru atau pilih yang ada
   c. Di search bar ketik "OAuth consent screen" → setup:
      - User type: **External**
      - App name: **Finansial OS**
      - Support email: email kamu
   d. Klik **Credentials** → **Create Credentials** → **OAuth 2.0 Client IDs**
   e. Application type: **Web application**
   f. Authorized redirect URIs → tambahkan:
      `https://abcxyz.supabase.co/auth/v1/callback`
      (ganti `abcxyz` dengan Project ID Supabase kamu)
   g. Klik **Create** → copy **Client ID** dan **Client Secret**

4. Paste Client ID dan Client Secret ke form di Supabase → **Save**

---

## LANGKAH 2 — SETUP PEMBAYARAN (20 menit)

### Opsi A — Gumroad (paling mudah, cocok untuk mulai)

1. Daftar di `gumroad.com`
2. Klik **New Product** → pilih **Subscription**
3. Isi:
   - **Name:** Finansial OS Pro
   - **Price:** USD $5/year (setara ~Rp 79.000)
   - **Billing period:** Yearly
4. Di **Content** → upload file `dashboard.html` sebagai delivery (atau link ke app)
5. Publish → copy link produk
6. Di `dashboard.html`, ganti:
   ```javascript
   const PAYMENT_URL = 'GANTI_DENGAN_LINK_PEMBAYARAN';
   ```
   Dengan link Gumroad kamu.

### Opsi B — Midtrans (untuk pembayaran Rupiah langsung)

1. Daftar di `midtrans.com` → pilih Sandbox dulu untuk testing
2. Di Dashboard Midtrans → **Settings** → **Access Keys** → copy **Server Key** dan **Client Key**
3. Untuk integrasi penuh butuh backend sederhana — rekomendasinya pakai **Supabase Edge Functions**:

   Di Supabase → **Edge Functions** → **New Function** → nama: `create-payment`

   ```typescript
   // supabase/functions/create-payment/index.ts
   import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

   const MIDTRANS_SERVER_KEY = Deno.env.get('MIDTRANS_SERVER_KEY')!

   serve(async (req) => {
     const { userId, email, name } = await req.json()
     const orderId = `FOS-${userId}-${Date.now()}`

     const response = await fetch('https://app.sandbox.midtrans.com/snap/v1/transactions', {
       method: 'POST',
       headers: {
         'Content-Type': 'application/json',
         'Authorization': `Basic ${btoa(MIDTRANS_SERVER_KEY + ':')}`
       },
       body: JSON.stringify({
         transaction_details: { order_id: orderId, gross_amount: 79000 },
         customer_details: { email, first_name: name },
         item_details: [{ id: 'FINANSIAL-OS-PRO', price: 79000, quantity: 1, name: 'Finansial OS Pro — Langganan Tahunan' }]
       })
     })

     const data = await response.json()
     return new Response(JSON.stringify({ token: data.token, redirect_url: data.redirect_url }), {
       headers: { 'Content-Type': 'application/json' }
     })
   })
   ```

4. Setelah pembayaran sukses, update tabel `subscriptions` via webhook Midtrans.

**Rekomendasi untuk launch pertama:** Pakai **Gumroad** dulu — setup 10 menit, langsung terima pembayaran. Setelah revenue stabil, migrasi ke Midtrans untuk pengalaman yang lebih lokal.

---

## LANGKAH 3 — DEPLOY KE NETLIFY (10 menit)

### 3.1 Siapkan folder project

Struktur folder yang dibutuhkan:
```
finansial-os-app/
├── index.html
├── dashboard.html
├── manifest.json
├── icon-192.png    ← buat atau download icon 192x192px
└── icon-512.png    ← buat atau download icon 512x512px
```

Untuk icon sementara, bisa download dari:
`https://via.placeholder.com/192/7F77DD/ffffff?text=FOS`

### 3.2 Deploy via Netlify Drop

1. Buka `drop.netlify.com`
2. Daftar akun gratis di `app.netlify.com/signup`
3. Drag & drop seluruh folder `finansial-os-app` ke kotak Netlify
4. Tunggu 30 detik → dapat link seperti `https://amazing-name-123.netlify.app`

### 3.3 Set custom domain (opsional)

Di Netlify dashboard → **Domain settings** → **Add custom domain**
- Contoh: `app.jujurfinansial.com`
- Butuh akses ke DNS domain kamu

### 3.4 Update Supabase redirect URL

Setelah dapat link Netlify:
1. Di Supabase → **Authentication** → **URL Configuration**
2. **Site URL:** `https://amazing-name-123.netlify.app`
3. **Redirect URLs:** tambahkan `https://amazing-name-123.netlify.app/dashboard.html`
4. Di Google Cloud Console → tambahkan juga ke **Authorized redirect URIs**

---

## LANGKAH 4 — AKTIFKAN PWA (15 menit)

Agar aplikasi bisa diinstall di HP seperti app sungguhan:

### 4.1 Tambahkan Service Worker

Buat file baru `sw.js` di folder project:

```javascript
// sw.js — Service Worker untuk Finansial OS
const CACHE = 'finansial-os-v1';
const ASSETS = ['/', '/index.html', '/dashboard.html', '/manifest.json'];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(ASSETS))
  );
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request))
  );
});
```

### 4.2 Register Service Worker

Tambahkan kode ini sebelum `</body>` di KEDUA file HTML:

```html
<script>
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
      .then(() => console.log('SW registered'))
      .catch(e => console.log('SW error:', e));
  }
</script>
```

### 4.3 Cara install di HP

**Android (Chrome):**
1. Buka link app di Chrome
2. Muncul banner "Add to Home Screen" otomatis, atau
3. Ketuk titik tiga di pojok kanan → "Add to Home screen"

**iOS (Safari):**
1. Buka link di Safari
2. Ketuk ikon Share (kotak dengan panah ke atas)
3. Scroll ke bawah → "Add to Home Screen"

---

## LANGKAH 5 — KELOLA SUBSCRIBER (manual dulu)

Untuk awal, aktifasi langganan bisa dilakukan manual:

### Setelah pembayaran masuk via Gumroad:

1. Buka Supabase → **Table Editor** → tabel `subscriptions`
2. Cari row dengan `user_id` pembeli
3. Update field:
   - `plan`: ubah dari `trial` ke `pro`
   - `expires_at`: ubah ke satu tahun ke depan
   - `payment_ref`: isi dengan nomor order Gumroad

### Query SQL cepat untuk aktivasi:

```sql
-- Ganti 'email@pembeli.com' dan tanggal sesuai kebutuhan
UPDATE subscriptions
SET
  plan        = 'pro',
  status      = 'active',
  expires_at  = '2027-01-01 00:00:00+00',
  payment_ref = 'GUMROAD-ORDER-ID'
WHERE user_id = (
  SELECT id FROM auth.users WHERE email = 'email@pembeli.com'
);
```

Jalankan di **SQL Editor** Supabase setiap ada pembayaran masuk.

---

## CHECKLIST SEBELUM LAUNCH

- [ ] Supabase URL dan Anon Key sudah diisi di kedua file HTML
- [ ] Tabel `user_data` dan `subscriptions` sudah dibuat
- [ ] Google OAuth sudah aktif di Supabase
- [ ] Link pembayaran sudah diisi di `dashboard.html`
- [ ] File sudah di-deploy ke Netlify
- [ ] Redirect URL sudah diupdate di Supabase dan Google Console
- [ ] Test login dengan akun Google sendiri
- [ ] Test trial 7 hari muncul setelah daftar
- [ ] Test paywall muncul setelah trial expired
- [ ] Test aktivasi manual subscriber pertama

---

## HARGA & BIAYA OPERASIONAL

| Layanan       | Plan       | Biaya       |
|---------------|------------|-------------|
| Supabase      | Free       | Gratis s/d 50.000 MAU |
| Netlify       | Free       | Gratis s/d 100GB bandwidth |
| Gumroad       | -          | 10% per transaksi |
| Google Cloud  | -          | Gratis untuk OAuth |
| **Total awal**| -          | **Rp 0/bulan** |

Dengan Rp 79.000/subscriber/tahun:
- 10 subscriber → Rp 711.000/tahun (setelah komisi Gumroad)
- 50 subscriber → Rp 3.555.000/tahun
- 100 subscriber → Rp 7.110.000/tahun

---

## SUPPORT

Channel YouTube: `youtube.com/@jujurfinansial`

Jika ada pertanyaan teknis saat setup, dokumentasi lengkap ada di:
- Supabase: `supabase.com/docs`
- Netlify: `docs.netlify.com`
- Midtrans: `docs.midtrans.com`
